from . import core

__version__ = "0.1.4"
__author__ = "Gavin Kerr"
__email__ = "gavin.kerr@dal.ca"
__all__ = ["core"]
