# pytex-lib

Allows you to output your python functions directly to a LaTeX file.

